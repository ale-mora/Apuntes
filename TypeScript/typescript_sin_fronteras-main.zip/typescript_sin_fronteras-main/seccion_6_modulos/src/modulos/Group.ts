export default class Group {
  constructor(public readonly id: number, public name: string) { }
}

export const defaultgroups = {
  users: "users",
  admins: "admins",
}

const manejaUsuarios = () => {

}