// /**
//  * 
//  * @param {string} mensaje
//  * @param {string} mensaje2
//  * @returns {string} 
//  */ 

export function holamundo(mensaje, mensaje2){
  console.log(`Hola mundo ${mensaje} ${mensaje2}`);

  return mensaje;
}