import { holamundo } from './saludos';

holamundo("Chanchito Feliz", "Hola Mundo")