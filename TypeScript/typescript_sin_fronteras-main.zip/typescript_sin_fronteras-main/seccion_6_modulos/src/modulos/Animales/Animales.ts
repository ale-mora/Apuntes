export class Animales { }
