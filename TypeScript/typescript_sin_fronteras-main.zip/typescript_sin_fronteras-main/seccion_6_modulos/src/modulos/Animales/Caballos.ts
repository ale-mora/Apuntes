export class Caballos { }
