export { Animales } from "./Animales";
export { Chanchitos } from "./Chanchitos";
export { Caballos } from "./Caballos";

// export {
//   Animales,
//   Chanchitos,
//   Caballos
// }