export class Point {
  constructor(public x: number, public y: number) { }
}

export const PUNTITO = { x: 23, y: 24 };